# Guide des Compléments Alimentaires

## Essentiels

### Protéine Whey
- Dosage: 20-30g post-entraînement
- Bénéfices: Récupération musculaire
- Timing: Dans les 30 min après l'effort

### BCAA
- Dosage: 5-10g
- Bénéfices: Préservation musculaire
- Timing: Pendant l'entraînement

### Créatine
- Dosage: 5g/jour
- Bénéfices: Force et puissance
- Timing: N'importe quand dans la journée

## Optionnels

### Multivitamines
- Dosage: 1 comprimé
- Bénéfices: Santé générale
- Timing: Avec un repas

### Oméga-3
- Dosage: 2-3g
- Bénéfices: Anti-inflammatoire
- Timing: Avec les repas