# Plans de Repas

## Plan Standard (2000 kcal)

### Petit-déjeuner (500 kcal)
- Flocons d'avoine (60g)
- Banane (1)
- Œufs brouillés (2)
- Lait d'amande (200ml)

### Collation (200 kcal)
- Yaourt grec (150g)
- Fruits rouges (100g)
- Noix (30g)

### Déjeuner (600 kcal)
- Poulet grillé (150g)
- Riz complet (70g)
- Légumes variés (200g)
- Huile d'olive (1cs)

### Collation (200 kcal)
- Pomme (1)
- Beurre de cacahuète (20g)

### Dîner (500 kcal)
- Saumon (150g)
- Quinoa (60g)
- Légumes verts (200g)
- Avocat (1/2)