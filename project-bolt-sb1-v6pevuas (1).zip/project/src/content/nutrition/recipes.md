# Recettes Healthy

## Petit-déjeuner

### Bowl Protéiné
- 40g flocons d'avoine
- 30g protéine whey
- 1 banane
- 10g graines de chia
- Lait d'amande
- Cannelle

### Pancakes Protéinés
- 1 œuf
- 30g flocons d'avoine
- 1 scoop protéine
- 100ml lait d'amande
- 1/2 banane

## Déjeuner/Dîner

### Bowl Buddha au Quinoa
- 70g quinoa
- 150g pois chiches
- Légumes rôtis
- Avocat
- Sauce tahini

### Wrap au Poulet
- Galette de blé complet
- 120g poulet grillé
- Légumes crus
- Houmous
- Épinards