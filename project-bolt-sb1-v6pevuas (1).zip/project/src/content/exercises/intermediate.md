# Programme Intermédiaire

## Semaine 1-4

### Jour 1 - Push
- Push-ups diamant (4x12)
- Dips (4x10)
- Développé militaire (4x12)
- Élévations latérales (4x15)
- Extensions triceps (4x15)
- Planche dynamique (4x45s)

### Jour 2 - Pull
- Tractions assistées (4x8)
- Rowing inversé (4x12)
- Face pull (4x15)
- Curl biceps alterné (4x12)
- Curl marteau (4x12)

### Jour 3 - Legs
- Squats sautés (4x15)
- Fentes bulgares (4x12/jambe)
- Hip thrust (4x15)
- Mollets sautés (4x25)
- Wall sit (4x60s)