# Programme Avancé

## Semaine 1-4

### Jour 1 - Push Power
- Push-ups lesté (5x12)
- Dips lestés (5x10)
- Handstand push-ups (5x8)
- Pike push-ups (5x12)
- Planche RTO (5x30s)

### Jour 2 - Pull Power
- Muscle ups (5x5)
- Tractions lestées (5x8)
- Front lever progressions (5x10s)
- Back lever progressions (5x10s)
- Dragon flags (5x8)

### Jour 3 - Legs Power
- Pistol squats (5x8/jambe)
- Shrimp squats (5x8/jambe)
- Sauts en profondeur (5x10)
- Sprint (8x30m)
- L-sit (5x20s)