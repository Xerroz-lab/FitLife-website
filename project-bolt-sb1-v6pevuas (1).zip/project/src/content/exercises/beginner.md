# Programme Débutant

## Semaine 1-4

### Jour 1 - Haut du Corps
- Push-ups (3x8)
- Dips assistés (3x8)
- Rowing avec élastique (3x12)
- Élévations latérales (3x12)
- Curl biceps (3x12)
- Planche (3x30s)

### Jour 2 - Bas du Corps
- Squats (3x12)
- Fentes (3x10/jambe)
- Pont fessier (3x15)
- Mollets (3x20)
- Gainage latéral (3x30s/côté)

### Jour 3 - Full Body
- Burpees (3x10)
- Mountain climbers (3x30s)
- Jumping jacks (3x30)
- Crunchs (3x20)
- Superman (3x12)